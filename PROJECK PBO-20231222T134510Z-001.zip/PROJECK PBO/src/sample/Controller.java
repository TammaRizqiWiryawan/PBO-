package sample;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class Controller {
    @FXML
    Stage stage;
    @FXML
    Scene scene;
    @FXML
    private TextField userNameTextField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Label loginMessageLabel;

    database database = new database();

@FXML
private void handleLoginButtonAction(ActionEvent event) throws IOException {
    String username = userNameTextField.getText();
    String password = passwordField.getText();

    // Periksa apakah username dan password tidak kosong
    if (username.isEmpty() || password.isEmpty()) {
        loginMessageLabel.setText("MASUKIN ID PASSWORD EUJ");
        return; // Keluar dari metode karena ada kesalahan
    }

    // Panggil metode untuk memeriksa login ke database
    String userRole = database.getUserRole(username, password);
    if (userRole != null) {
        if (userRole.equals("manajer")) {
            // Redirect ke laman manajer jika peran adalah manajer
            System.out.println("Login berhasil sebagai manajer!");
            Parent root = FXMLLoader.load(getClass().getResource("lamaanmanajer.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Halaman Utama Manajer");
            stage.setScene(new Scene(root, 600, 400));
            stage.show();
        } else if (userRole.equals("karyawan")) {
            // Redirect ke laman karyawan jika peran adalah karyawan
            System.out.println("Login berhasil sebagai karyawan!");
            Parent root = FXMLLoader.load(getClass().getResource("lamanTable.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Halaman Utama Karyawan");
            stage.setScene(new Scene(root, 600, 400));
            stage.show();
        } else {
            loginMessageLabel.setText("Peran pengguna tidak valid");
        }
    } else {
        loginMessageLabel.setText("Mohon masukkan Username dan Password dengan benar");
        // Tambahkan logika untuk menangani login gagal
        }
    }
}
