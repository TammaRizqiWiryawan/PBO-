package sample;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class controllermanajer {

    @FXML
    private Button hapususer;

    @FXML
    private TableColumn<UserModel, String> manajerpassword;

    @FXML
    private TableColumn<UserModel, String> manajerrole;

    @FXML
    private TableColumn<UserModel, String> manajerusername;

    @FXML
    private Button tambahuser;

    @FXML
    private TextField txtpassword;

    @FXML
    private TextField txtrole;

    @FXML
    private TextField txtusername;

    @FXML
    private TableView<UserModel> userTableView;

    @FXML
    void deleteUser(ActionEvent event) {
        int myIndex = userTableView.getSelectionModel().getSelectedIndex();
    
        if (myIndex != -1) {
            String username = userTableView.getItems().get(myIndex).getUsername();
    
            try {
                Connection con;
                PreparedStatement pst;
                // Gunakan instans db untuk mendapatkan koneksi
                con = db.getConnection(); // Inisialisasi koneksi di sini
                pst = con.prepareStatement("DELETE FROM login WHERE username = ?");
                pst.setString(1, username);
                pst.executeUpdate();
    
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("HAPUS");
                alert.setHeaderText("INFO USER");
                alert.setContentText("USER TELAH DIHAPUS!");
                alert.showAndWait();
    
                // Memperbarui tampilan tabel
                userTableView.refresh();
                loadUserData();
    
            } catch (SQLException e) {
                System.out.println(e.getMessage());
                Logger.getLogger(controllermanajer.class.getName()).log(Level.SEVERE, null, e);
            }
        } else {
            // Tampilkan pesan atau lakukan tindakan jika tidak ada baris yang dipilih
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Peringatan");
            alert.setHeaderText(null);
            alert.setContentText("Pilih user yang ingin dihapus!");
            alert.showAndWait();
        }
    }
    
    @FXML
    void tambahUser(ActionEvent event) {
        String username = txtusername.getText();
        String password = txtpassword.getText();
        String role = txtrole.getText();
    
        try {
            // Validasi input
            if (username.isEmpty() || password.isEmpty() || role.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Error", null, "Harap isi semua field!");
                return; // Keluar dari metode jika input tidak valid
            }
    
            // Panggil metode untuk menambahkan user ke database
            boolean success = db.addUser(username, password, role);
    
            if (success) {
                // Jika penambahan user berhasil, muat ulang data ke TableView
                loadUserData();
    
                // Clear input fields setelah berhasil menambahkan user
                txtusername.clear();
                txtpassword.clear();
                txtrole.clear();
    
                // Menampilkan pesan berhasil
                showAlert(Alert.AlertType.INFORMATION, "POP UP", "nambah karyawan", "BERHASIL NAMBAH");
            } else {
                // Tampilkan pesan kesalahan jika penambahan user gagal
                // Anda dapat menggunakan Alert untuk memberi tahu pengguna
                showAlert(Alert.AlertType.ERROR, "Error", null, "Gagal menambahkan karyawan. Silakan coba lagi.");
            }
        } catch (Exception e) {
            Logger.getLogger(controllermanajer.class.getName()).log(Level.SEVERE, null, e);
            // Handle exception sesuai kebutuhan Anda
            showAlert(Alert.AlertType.ERROR, "Error", null, "Terjadi kesalahan: " + e.getMessage());
        }
    }
    

// Metode bantuan untuk menampilkan alert
private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(header);
    alert.setContentText(content);
    alert.showAndWait();
}


    private void loadUserData() {
        // Memuat data dari database ke TableView
        ObservableList<UserModel> userList = db.fetchUserData();
        userTableView.setItems(userList);
    }

    private database db = new database();

    @FXML
    private void initialize() {
        // Inisialisasi kolom pada TableView
        manajerusername.setCellValueFactory(new PropertyValueFactory<>("username"));
        manajerpassword.setCellValueFactory(new PropertyValueFactory<>("password"));
        manajerrole.setCellValueFactory(new PropertyValueFactory<>("role"));

        // Memuat data dari database ke TableView
        loadUserData();
    }

} // Kurung kurawal penutup kelas
