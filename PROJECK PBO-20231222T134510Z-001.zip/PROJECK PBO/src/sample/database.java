package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class database {
    
    private Connection connection;

    public database() {
        databaseConnection();
    }
    public String getUserRole(String username, String password) {
        try {
            String query = "SELECT role FROM login WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
    
            ResultSet resultSet = preparedStatement.executeQuery();
    
            if (resultSet.next()) {
                return resultSet.getString("role");
            }
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    
        return null; // Jika tidak ada hasil atau terjadi kesalahan
    }
    
    public boolean addUser(String username, String password, String role) {
        try {
            String query = "INSERT INTO login (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, role);

            // Eksekusi pernyataan SQL untuk menambahkan pengguna baru
            int rowsAffected = preparedStatement.executeUpdate();

            // Jika baris terpengaruh lebih dari 0, berarti penambahan berhasil
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Jika terjadi kesalahan
        }
    }
    

    public void databaseConnection(){
        String jdbcUrl = "jdbc:mysql://localhost:3306/loginform";
        String dbUsername = "root";
        String dbPassword = "";

        try {
            connection =DriverManager.getConnection(jdbcUrl, dbUsername, dbPassword);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public Connection getConnection() {
        return connection;
    }
    public boolean authenticateUser(String username, String password) {
        try {
            String query = "SELECT * FROM login WHERE username = ? AND password = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();
                // Jika ada hasil, berarti autentikasi berhasil
            return resultSet.next();
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
//buat set database
    public ObservableList<ObatModel> fetchDataFromDatabase() {
        ObservableList<ObatModel> obatList = FXCollections.observableArrayList();
    
        try {
            String query = "SELECT NamaObat, ExpiredDate, Stok, Harga FROM infoobat";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                obatList.add(new ObatModel( resultSet.getString("NamaObat"),
                                            resultSet.getString("ExpiredDate"), 
                                            resultSet.getInt("Stok"), 
                                            resultSet.getInt("Harga")));
                
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return obatList;
    }
    public ObservableList<UserModel> fetchUserData() {
                ObservableList<UserModel> userList = FXCollections.observableArrayList();
    
        try {
            String query = "SELECT username, password, role FROM login";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                userList.add(new UserModel( resultSet.getString("username"),
                                            resultSet.getString("password"), 
                                            resultSet.getString("role")));

    }
} catch (SQLException e){
    e.printStackTrace();
}
return userList;
    }
}