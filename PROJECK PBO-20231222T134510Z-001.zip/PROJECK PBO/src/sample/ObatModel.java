package sample;

public class ObatModel {
    String namaObat;
    String expiredDate;
    int stok, harga;
//manggil 
    public ObatModel(String namaObat, String expiredDate, int stok, int harga) {
        this.namaObat = namaObat;
        this.expiredDate = expiredDate;
        this.stok = stok;
        this.harga = harga;
    
    }

    public String getNamaObat() {
        return namaObat;
    }

    public String getExpiredDate() {
        return expiredDate;
    }

    public int getStok() {
        return stok;
    }

    public int getHarga() {
        return harga;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
    }

    public void setExpiredDate(String expiredDate) {
        this.expiredDate = expiredDate;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    
}