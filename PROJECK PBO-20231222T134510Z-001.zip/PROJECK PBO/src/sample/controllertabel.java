    package sample;
    import javafx.collections.ObservableList;
    import javafx.fxml.FXML;
    import javafx.scene.control.*;
    import javafx.scene.control.cell.PropertyValueFactory;
    import javafx.fxml.Initializable;
    import java.net.URL;
    import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert.AlertType;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import java.sql.*;


    public class controllertabel implements Initializable{
        @FXML
        private TextField userNameTextField;
        @FXML
        private PasswordField passwordField;
        @FXML
        private Label loginMessageLabel;
        @FXML
        private TableView<ObatModel> obatTableView;
        @FXML
        private TableColumn<ObatModel, String> namaObat;
        @FXML
        private TableColumn<ObatModel, String> expiredDate;
        @FXML
        private TableColumn<ObatModel, Integer> stok;
        @FXML
        private TableColumn<ObatModel, Integer> harga;
        @FXML
        private Button hapus;
        @FXML
        private Button tambah;
        @FXML
        private Button edit;
          @FXML
        private TextField txtexpdate;

        @FXML
        private TextField txtharga;

        @FXML
        private TextField txtnamobat;

    @FXML
    private TextField txtstok;

    @FXML
    void add(ActionEvent event) {
        String namobat = txtnamobat.getText();
        String expdate = txtexpdate.getText();
        String stokText = txtstok.getText();
        String hargaText = txtharga.getText();
    
        try {
            // Validasi input
            if (namobat.isEmpty() || expdate.isEmpty() || stokText.isEmpty() || hargaText.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Error", null, "Harap isi semua field!");
                return; // Keluar dari metode jika input tidak valid
            }
    
            // Mengonversi nilai Stok dan Harga menjadi angka
            int stok, harga;
    
            try {
                stok = Integer.parseInt(stokText);
                harga = Integer.parseInt(hargaText);
            } catch (NumberFormatException e) {
                showAlert(Alert.AlertType.ERROR, "Error", null, "Nilai Stok dan Harga harus berupa angka!");
                return; // Keluar dari metode jika input tidak valid
            }
    
            // Membuat objek database dan menginisialisasi koneksi
            database database = new database();
            database.databaseConnection();
    
            // Mendapatkan koneksi dari objek database
            Connection con = database.getConnection();
    
            // Membuat PreparedStatement untuk query insert
            PreparedStatement pst = con.prepareStatement("insert into infoobat(NamaObat, ExpiredDate, Stok, Harga) values (?, ?, ?, ?)");
            pst.setString(1, namobat);
            pst.setString(2, expdate);
            pst.setInt(3, stok);
            pst.setInt(4, harga);
    
            // Mengeksekusi query insert
            pst.executeUpdate();
            
            // Menampilkan pesan berhasil
            showAlert(Alert.AlertType.INFORMATION, "POP UP", "nambah obat", "BERHASIL NAMBAH");
    
            // Membersihkan input setelah berhasil diinsert
            txtnamobat.setText("");
            txtexpdate.setText("");
            txtstok.setText("");
            txtharga.setText("");
            txtnamobat.requestFocus();
    
            // Clear list dan muat ulang data dari database
            list.clear();
            list.addAll(database.fetchDataFromDatabase());
    
            // Memperbarui tampilan tabel
            obatTableView.refresh();
    
        } catch (SQLException e) {
            Logger.getLogger(controllertabel.class.getName()).log(Level.SEVERE, null, e);
            // Handle exception sesuai kebutuhan Anda
            showAlert(Alert.AlertType.ERROR, "Error", null, "Terjadi kesalahan saat menambahkan obat: " + e.getMessage());
        }
    }
    
    // Metode bantuan untuk menampilkan alert
    private void showAlert(Alert.AlertType alertType, String title, String header, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
        
@FXML
void delete(ActionEvent event) {
    int myIndex;
    myIndex = obatTableView.getSelectionModel().getSelectedIndex();

    if (myIndex != -1) {
        ObatModel selectedObat = obatTableView.getItems().get(myIndex);
        String namaObat = selectedObat.getNamaObat();

        try {
            Connection con = database.getConnection();
            PreparedStatement pst = con.prepareStatement("DELETE FROM infoobat WHERE NamaObat = ?");
            pst.setString(1, namaObat);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("HAPUS");
            alert.setHeaderText("INFO OBAT");
            alert.setContentText("OBAT TELAH DIHAPUS!");
            alert.showAndWait();

            // Memperbarui tampilan tabel
            obatTableView.getItems().remove(myIndex);

        } catch (SQLException e) {
            Logger.getLogger(controllertabel.class.getName()).log(Level.SEVERE, null, e);
        }
    } else {
        // Tampilkan pesan jika tidak ada baris yang dipilih
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Peringatan");
        alert.setHeaderText(null);
        alert.setContentText("Pilih obat yang ingin dihapus!");
        alert.showAndWait();
    }
}
        
@FXML
void update(ActionEvent event) {
    try {
        int selectedIndex = obatTableView.getSelectionModel().getSelectedIndex();

        if (selectedIndex >= 0) {
            ObatModel selectedObat = obatTableView.getItems().get(selectedIndex);

            // Dapatkan nilai-nilai yang diubah
            String updatedNamaObat = txtnamobat.getText();
            String updatedExpiredDate = txtexpdate.getText();
            int updatedStok = Integer.parseInt(txtstok.getText());
            int updatedHarga = Integer.parseInt(txtharga.getText());

            Connection con = database.getConnection();
            PreparedStatement pst = con.prepareStatement("UPDATE infoobat SET NamaObat=?, ExpiredDate=?, Stok=?, Harga=? WHERE NamaObat=?");
            pst.setString(1, updatedNamaObat);
            pst.setString(2, updatedExpiredDate);
            pst.setInt(3, updatedStok);
            pst.setInt(4, updatedHarga);
            pst.setString(5, selectedObat.getNamaObat());
            pst.executeUpdate();

            // Perbarui tampilan tabel dengan data yang baru
            selectedObat.setNamaObat(updatedNamaObat);
            selectedObat.setExpiredDate(updatedExpiredDate);
            selectedObat.setStok(updatedStok);
            selectedObat.setHarga(updatedHarga);

            obatTableView.refresh();

            // Setelah pembaruan berhasil, bersihkan komponen input
            txtnamobat.clear();
            txtexpdate.clear();
            txtstok.clear();
            txtharga.clear();

            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Update Information");
            alert.setHeaderText(null);
            alert.setContentText("Data berhasil diperbarui!");
            alert.showAndWait();
        } else {
            // Jika tidak ada baris yang dipilih, tampilkan pesan kesalahan
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setHeaderText(null);
            alert.setContentText("Pilih baris yang akan diperbarui!");
            alert.showAndWait();
        }
    } catch (SQLException e) {
        Logger.getLogger(controllertabel.class.getName()).log(Level.SEVERE, null, e);

        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Error during update: " + e.getMessage());
        alert.showAndWait();
    }
}
        
    Connection con;
    PreparedStatement pst;

        database database = new database();

        ObservableList<ObatModel> list;

        @Override//buat nampilin databaseanjay
        public void initialize(URL url, ResourceBundle rb) {
            // Menginisialisasi tabel setelah tampilan utama ditampilkan
            namaObat.setCellValueFactory(new PropertyValueFactory<ObatModel, String>("namaObat"));
            expiredDate.setCellValueFactory(new PropertyValueFactory<ObatModel, String>("expiredDate"));
            stok.setCellValueFactory(new PropertyValueFactory<ObatModel, Integer>("stok"));
            harga.setCellValueFactory(new PropertyValueFactory<ObatModel, Integer>("harga"));
            
            list = database.fetchDataFromDatabase();
            obatTableView.setItems(list);
            obatTableView.refresh();
            
        }
    }
